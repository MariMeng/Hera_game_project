package heras;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class PacManGame extends JPanel implements ActionListener, KeyListener {
    private static final int TILE_SIZE = 40;
    private static final int MAZE_WIDTH = 17; // Tamanho aumentado
    private static final int MAZE_HEIGHT = 17; // Tamanho aumentado

    private Labirinto labirinto;
    private PacMan pacMan;
    private Image fundo;
    private JButton botao;
    private boolean iniciar;
    private JPanel titlePanel;
    
    public PacManGame(int[][] mazeLayout) {
        setLayout(new CardLayout());
        iniciar = false;

        // Carregar a imagem de fundo
        fundo = new ImageIcon("res/fundoMenu.png").getImage();
        if (fundo == null) {
            System.err.println("Erro ao carregar a imagem de fundo.");
        }

        // Configura o painel de título
        titlePanel = new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fundo != null) {
                    g.drawImage(fundo, 0, 0, getWidth(), getHeight(), this); // Desenha o fundo
                }
                // Desenha o botão sobre o fundo
                botao.paint(g);
            }
        };
        titlePanel.setLayout(new GridBagLayout());
        botao = new JButton("Iniciar Jogo");
        botao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!iniciar) {
                    startGame();
                }
            }
        });

        // Adiciona o botão ao painel de título
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(150, 20, 20, 20);
        titlePanel.add(botao, gbc);

        // Configura o painel de jogo
        JPanel gamePanel = new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (iniciar) {
                    labirinto.render(g);
                    pacMan.render(g);
                    g.setColor(Color.WHITE);
                    g.setFont(new Font("Arial", Font.PLAIN, 20));
                    g.drawString("Cristais: " + labirinto.getCrystalCount(), 10, 20);
                    
                    g.setColor(Color.WHITE);
                    g.drawString("Posição: (" + pacMan.getX() + ", " + pacMan.getY() + ")", getWidth() - 150, 20);
                }
            }
        };
        gamePanel.setLayout(new BorderLayout());
        
        String[] esquerda = {
            "res/esq1.png",
            "res/esq2.png",
            "res/esq3.png",
            "res/esq4.png"
        };
        String[] direita = {
            "res/direita1.png",
            "res/direita2.png",
            "res/direita3.png",
            "res/direita4.png"
        };
      
        if (mazeLayout.length != MAZE_WIDTH || (MAZE_WIDTH > 0 && mazeLayout[0].length != MAZE_HEIGHT)) {
            throw new IllegalArgumentException("O tamanho do labirinto não corresponde às dimensões fornecidas.");
        }
        
        add(titlePanel, "Title");
        add(gamePanel, "Game");
        labirinto = new Labirinto(MAZE_WIDTH, MAZE_HEIGHT, TILE_SIZE, mazeLayout);
        pacMan = new PacMan(1, 1, 40, 1, direita, esquerda, 180); 

        Timer timer = new Timer(16, this); // Aproximadamente 60 FPS
        timer.start();
        addKeyListener(this);
        setFocusable(true);
    }
    
    private void startGame() {
        iniciar = true;
        ((CardLayout) getLayout()).show(this, "Game");
        Timer timer = new Timer(2000, this);
        timer.start();
        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!iniciar) {
            if (fundo != null) {
                g.drawImage(fundo, 0, 0, getWidth(), getHeight(), this); 
            } else {
                g.setColor(Color.BLACK);
                g.drawString("Erro ao carregar imagem de fundo.", 20, 20);
                
                
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (iniciar) {
            pacMan.tick(labirinto);
            labirinto.update();
            repaint();
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        pacMan.setDirection(Vetores.fromKeyEvent(e));
    }

    @Override
    public void keyReleased(KeyEvent e) {
        pacMan.stopMovement(Vetores.fromKeyEvent(e));
    }

    @Override
    public void keyTyped(KeyEvent e) { }

    public static void main(String[] args) {
    	
        int[][] lab2 = {
        	    {5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5},
                {5, 0, 3, 0, 0, 0, 0, 1, 0, 0, 1, 0, 4, 0, 0, 3, 5},
                {5, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 5},
                {5, 0, 1, 1, 3, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 5},
                {5, 0, 1, 3, 1, 1, 4, 1, 0, 1, 1, 0, 1, 1, 1, 0, 5},
                {5, 0, 1, 0, 1, 3, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 5},
                {5, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 5},
                {5, 3, 0, 0, 1, 0, 0, 0, 0, 1, 5, 1, 1, 0, 1, 5, 5},
                {5, 1, 1, 0, 1, 3, 4, 1, 1, 1, 1, 1, 1, 4, 1, 5, 5},
                {5, 0, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 3, 5},
                {5, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 5},
                {5, 0, 1, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 5},
                {5, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 5},
                {5, 0, 0, 0, 1, 0, 0, 4, 0, 0, 3, 1, 0, 1, 0, 4, 5},
                {5, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 5},
                {5, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 3, 5, 0, 3, 5},
                {5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 5}

        };

        JFrame frame = new JFrame("Heras");
        // Alterar (lab1 ou lab2)
        PacManGame game = new PacManGame(lab2);
        frame.add(game);
        frame.setSize(MAZE_WIDTH * TILE_SIZE, MAZE_HEIGHT * TILE_SIZE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((screenSize.width - frame.getWidth()) / 2, (screenSize.height - frame.getHeight()) / 2);

        frame.setVisible(true);
    }
}
