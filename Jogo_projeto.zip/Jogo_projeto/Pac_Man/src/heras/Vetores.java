package heras;

import java.awt.event.KeyEvent;


public class Vetores {
    public int x, y;

    public Vetores(int x, int y) {
        this.x = x;
        this.y = y;
    }
//transforma os comando em vetores
    public static Vetores fromKeyEvent(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                return new Vetores(-1, 0);
            case KeyEvent.VK_RIGHT:
                return new Vetores(1, 0);
            case KeyEvent.VK_UP:
                return new Vetores(0, -1);
            case KeyEvent.VK_DOWN:
                return new Vetores(0, 1);
            default:
                return new Vetores(0, 0);
        }
    }

    //somar dois vetores, é para poder calcular a por exemplo dois comandos, como direita e esquerda,
    //
    public Vetores add(Vetores v) {
        return new Vetores(this.x + v.x, this.y + v.y);
    }
//deixar mais rapido pea magnitude,
    public Vetores multiply(int scalar) {
        return new Vetores(this.x * scalar, this.y * scalar);
    }

    //calcular a distancia entre dois vetores
    public Vetores subtract(Vetores v) {
        return new Vetores(this.x - v.x, this.y - v.y);
    }

    //iguais, compara se estao na mesma direção ou posicao 
    
    public boolean equals(Vetores v) {
        return this.x == v.x && this.y == v.y;
    }
}
