package heras;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Labirinto {
    private static final int GHOST_BLOCK_TOGGLE_DELAY = 60; // Número de frames para piscar
    private int ghostBlockTimer = 0;
    private boolean showGhostBlocks = true;
    private int[][] maze;
    private int tileSize;
    private int width, height;
    private Image bloco;
    private Image fundo;
    private Image blocoBorda;
    private Image[] blocoFantasma;
    private Image[] cristalFrames;
    private int cristais;
    private int cristalFrameIndex = 0;
    private int cristalContagem = 0;
    private static final int CRISTAL_FRAME = 2; // Quantidade de atualizações por frame

    public Labirinto(int width, int height, int tileSize, int[][] mazeLayout) {
        this.width = width;
        this.height = height;
        this.tileSize = tileSize;
        this.maze = mazeLayout;
        blocoFantasma = new Image[7]; // Inicialize o array
        // Verificar se o labirinto eh consistente com a largura e altura fornecidas
        if (mazeLayout.length != height || (height > 0 && mazeLayout[0].length != width)) {
            throw new IllegalArgumentException("O tamanho do labirinto não corresponde às dimensões fornecidas.");
        }

        bloco = Toolkit.getDefaultToolkit().getImage("res/bloco101.png");
        for (int i = 0; i < 7; i++) {
            blocoFantasma[i] = Toolkit.getDefaultToolkit().getImage("res/fantasma" + (i + 1) + ".png");
        }
        
        fundo = Toolkit.getDefaultToolkit().getImage("res/fundo11.png");
        blocoBorda = Toolkit.getDefaultToolkit().getImage("res/bloco102.png");
        cristalFrames = new Image[8];
        for (int i = 0; i < 8; i++) {
            cristalFrames[i] = Toolkit.getDefaultToolkit().getImage("res/cristal" + (i + 1) + ".png");
        }

        // Esperar a imagem ser carregada
        MediaTracker tracker = new MediaTracker(new JPanel());
        tracker.addImage(bloco, 1);
        tracker.addImage(fundo, 0);
        
        for (Image cristalFrame : cristalFrames) {
            tracker.addImage(cristalFrame, 2);
        }
        for (Image fantasmaFrame : blocoFantasma) {
            tracker.addImage(fantasmaFrame, 4); 
        }
        try {
            tracker.waitForAll();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void render(Graphics g) {
        g.drawImage(fundo, 0, 0, width * tileSize, height * tileSize, null);
        ghostBlockTimer++;
        if (ghostBlockTimer >= GHOST_BLOCK_TOGGLE_DELAY) {
            ghostBlockTimer = 0;
            showGhostBlocks = !showGhostBlocks;
        }
        for (int y = 0; y < height; y++) { // Itera sobre as linhas
            for (int x = 0; x < width; x++) { // Itera sobre as colunas
                if (y >= maze.length || x >= maze[0].length) {
                    throw new ArrayIndexOutOfBoundsException("Índice fora dos limites da matriz.");
                }
                if (maze[y][x] == 1) {
                    g.drawImage(bloco, x * tileSize, y * tileSize, tileSize, tileSize, null);
                } else if (maze[y][x] == 3) {
                    g.drawImage(cristalFrames[cristalFrameIndex], x * tileSize, y * tileSize, tileSize, tileSize, null);
                } else if (maze[y][x] == 4 && showGhostBlocks) { 
                    g.setColor(new Color(255, 0, 0, 127)); // semi-transparente
                    g.drawImage(blocoFantasma[ghostBlockTimer / (GHOST_BLOCK_TOGGLE_DELAY / 7)], x * tileSize, y * tileSize, tileSize, tileSize, null);
                }else if (maze[y][x] == 5) {
                    g.drawImage(blocoBorda, x * tileSize, y * tileSize, tileSize, tileSize, null);
                }
            }
        }
    }
    
    public void update() {
        // Atualizar o frame da animação dos cristais
        cristalContagem++;
        if (cristalContagem >= CRISTAL_FRAME) {
            cristalContagem = 0;
            cristalFrameIndex = (cristalFrameIndex + 1) % cristalFrames.length;
        }
    }


//    public void checkCollisionsWithGhostBlocks(int pacManX, int pacManY) {
//        if (pacManX >= 0 && pacManX < width && pacManY >= 0 && pacManY < height && maze[pacManY][pacManX] == 4 && showGhostBlocks) {
//            // Exiba uma mensagem quando colidir com um bloco fantasma
//            JOptionPane.showMessageDialog(null, "Você colidiu com um bloco fantasma!");
//        }
//    }
    public boolean isWall(int x, int y) {
        if (x < 0 || x >= width || y < 0 || y >= height) return true;
        return maze[y][x] == 1 || (maze[y][x] == 4 && showGhostBlocks || maze[y][x] == 5); // Acesso correto à matriz
    }

    public boolean isCrystal(int x, int y) {
        if (x < 0 || x >= width || y < 0 || y >= height) return false;
        return maze[y][x] == 3; // Acesso correto à matriz
    }

    public void collectCrystal(int x, int y) {
        if (isCrystal(x, y)) {
            maze[y][x] = 0; // Remove o cristal do labirinto
            cristais++; // Incrementa a contagem de cristais coletados
        }
    }

    public int getCrystalCount() {
        return cristais;
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
}
