package heras;
import java.awt.Graphics;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.util.List;
import javax.swing.JPanel;
import java.util.ArrayList;

public class PacMan {
    private Vetores position;
    private Vetores velocity;
    private List<Image> direitaFrame; // Frames para a direita
    private List<Image> esquerdaFrame;  // Frames para a esquerda
    private int size;
    private int speed;
    private boolean comecaDireita; // Direção atual
    private int currentFrame;
    private long lastFrameChange;
    private long frameTempo; 

    public PacMan(int x, int y, int size, int speed, String[] direita, String[] esquerda, long frameTempo) {
      
    	
    	this.position = new Vetores(x, y);
        this.velocity = new Vetores(0, 0);
        
        
        
        this.size = size;
        this.speed = speed;
        this.frameTempo = frameTempo;
        this.currentFrame = 0;
        this.lastFrameChange = System.currentTimeMillis();
        this.comecaDireita = true; // 
        
        // Inicializa as listas de frames
        this.direitaFrame = new ArrayList<>();
        this.esquerdaFrame = new ArrayList<>();
        

        for (String path : direita) {
            Image image = Toolkit.getDefaultToolkit().getImage(path);
            MediaTracker tracker = new MediaTracker(new JPanel());
            tracker.addImage(image, 0);
            try {
                tracker.waitForAll();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            direitaFrame.add(image);
        }
        

        for (String path : esquerda) {
            Image image = Toolkit.getDefaultToolkit().getImage(path);
            MediaTracker tracker = new MediaTracker(new JPanel());
            tracker.addImage(image, 0);
            try {
                tracker.waitForAll();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            esquerdaFrame.add(image);
        }
    }

    public void setDirection(Vetores direction) {
        this.velocity = direction.multiply(speed);
        this.comecaDireita = direction.x > 0; 
    }

    public void stopMovement(Vetores direction) {
        if (this.velocity.equals(direction.multiply(speed))) {
            this.velocity = new Vetores(0, 0);
        }
    }

    public void tick(Labirinto labirinto) {
        Vetores nextPosition = position.add(velocity);
        if (!labirinto.isWall(nextPosition.x, nextPosition.y)) {
            position = nextPosition;
        }
        
        int pacManX = position.x ;
        int pacManY = position.y ;
    //    labirinto.checkCollisionsWithGhostBlocks(pacManX, pacManY);
        labirinto.collectCrystal(pacManX, pacManY);
        
        long now = System.currentTimeMillis();
        List<Image> currentFrames = comecaDireita ? direitaFrame : esquerdaFrame;
        if (now - lastFrameChange >= frameTempo) {
            if (currentFrames != null && !currentFrames.isEmpty()) {
                currentFrame = (currentFrame + 1) % currentFrames.size();
            }
            lastFrameChange = now;
        }
    }

    public void render(Graphics g) {
        List<Image> currentFrames = comecaDireita ? direitaFrame : esquerdaFrame;
        if (currentFrames != null && !currentFrames.isEmpty()) {
            g.drawImage(currentFrames.get(currentFrame), position.x * size, position.y * size, size, size, null);
        }
    }
    
    public int getX() {
        return position.x;
    }

    public int getY() {
        return position.y;
    }

}
