package heras;

import java.awt.Graphics;
import java.awt.Color;

public class Parede {
    private int x, y, largura, altura;

    public Parede(int x, int y, int largura, int altura) {
        this.x = x;
        this.y = y;
        this.largura = largura;
        this.altura = altura;
    }

    public void render(Graphics g) {
        g.setColor(Color.RED);
        g.fillRect(x, y, largura, altura);
    }
}
